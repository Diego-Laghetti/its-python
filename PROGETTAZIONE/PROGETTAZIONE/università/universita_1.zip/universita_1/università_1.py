from My_types import *
from datetime import datetime, time


class Citta:
    def __init__(self, nome: str, regione: 'Regione'):
        self._nome = nome
        self._regione = None
        self.set_regione(regione)

    def set_regione(self, regione: 'Regione') -> None:
        if any(c.nome() == self._nome for c in regione.citta()):
            raise ValueError('Non possono esistere due città con lo stesso nome nella stessa regione')
        if self._regione:
            self._regione.remove_citta(self)
        self._regione = regione
        regione.add_citta(self)

    def nome(self) -> str:
        return self._nome

    def regione(self) -> 'Regione':
        return self._regione


class Regione:
    def __init__(self, nome: str, nazione: 'Nazione', citta: list['Citta'] | None = None):
        self._nome = nome
        self._citta = []
        self._nazione = None
        if citta:
            for c in citta:
                self.add_citta(c)
        self.set_nazione(nazione)

    def add_citta(self, citta: 'Citta') -> None:
        self._citta.append(citta)

    def remove_citta(self, citta: 'Citta') -> None:
        self._citta.remove(citta)

    def nome(self) -> str:
        return self._nome

    def set_nazione(self, nazione: 'Nazione') -> None:
        if any(r.nome() == self._nome for r in nazione.regioni()):
            raise ValueError('Non possono esistere due regioni con lo stesso nome nella stessa nazione')
        if self._nazione:
            self._nazione.remove_regione(self)
        self._nazione = nazione
        nazione.add_regione(self)

    def citta(self) -> list['Citta']:
        return self._citta


class Nazione:
    def __init__(self, nome: str, regioni: list['Regione'] | None = None):
        self._nome = nome
        self._regioni = []
        if regioni:
            for r in regioni:
                self.add_regione(r)

    def nome(self) -> str:
        return self._nome

    def regioni(self) -> list['Regione']:
        return self._regioni

    def add_regione(self, regione: 'Regione') -> None:
        self._regioni.append(regione)

    def remove_regione(self, regione: 'Regione') -> None:
        self._regioni.remove(regione)


class Facolta:
    def __init__(self, nome: str, corsi: list['Corso'] | None = None):
        self._nome = nome
        self._corsi = []
        if corsi:
            for c in corsi:
                self.add_corso(c)

    def nome(self) -> str:
        return self._nome

    def corsi(self) -> list['Corso']:
        return self._corsi

    def add_corso(self, corso: 'Corso') -> None:
        self._corsi.append(corso)

    def remove_corso(self, corso: 'Corso') -> None:
        self._corsi.remove(corso)


class Corso:
    def __init__(self, nome: str, facolta: 'Facolta', insegnamenti: list['Insegnamento'] | None = None):
        self._nome = nome
        self._facolta = facolta
        self._insegnamenti = []
        if insegnamenti:
            for i in insegnamenti:
                self.add_insegnamento(i)

    def nome(self) -> str:
        return self._nome

    def facolta(self) -> 'Facolta':
        return self._facolta

    def add_insegnamento(self, insegnamento: 'Insegnamento') -> None:
        self._insegnamenti.append(insegnamento)

    def remove_insegnamento(self, insegnamento: 'Insegnamento') -> None:
        self._insegnamenti.remove(insegnamento)

    def insegnamenti(self) -> list['Insegnamento']:
        return self._insegnamenti


class Insegnamento:
    def __init__(self, nome: str, codice: str, durata: time, corsi: list['Corso']):
        self._nome = nome
        self._codice = codice
        self._durata = durata
        self._corsi = []
        for c in corsi:
            self.add_corso(c)

    def nome(self) -> str:
        return self._nome

    def codice(self) -> str:
        return self._codice

    def durata(self) -> time:
        return self._durata

    def add_corso(self, corso: 'Corso') -> None:
        self._corsi.append(corso)

    def remove_corso(self, corso: 'Corso') -> None:
        self._corsi.remove(corso)

    def corsi(self) -> list['Corso']:
        return self._corsi


class Persona:
    def __init__(self, nome: str, cognome: str, codice_fiscale: str, is_studente: bool, is_professore: bool, citta: Citta, regione: Regione, nazione: Nazione, matricola: str | None = None, data_iscrizione: datetime | None = None, corsi_superati: dict['Corso', 'Voto'] | None = None, facolta: Facolta | None = None, insegnamenti: list['Insegnamento'] | None = None):
        if is_studente and is_professore:
            raise ValueError("Una persona non può essere sia studente che professore")

        self._nome = nome
        self._cognome = cognome
        self._codice_fiscale = codice_fiscale
        self._is_studente = is_studente
        self._is_professore = is_professore
        self._corsi_superati = {}
        self._insegnamenti = []

        if self._is_studente:
            if not (matricola and data_iscrizione):
                raise ValueError('Lo studente deve avere una matricola e una data di iscrizione')
            self._matricola = matricola
            self._data_iscrizione = data_iscrizione
            self._facolta = facolta
            if corsi_superati:
                for c, v in corsi_superati.items():
                    self.add_corso_superato(c, v)
            if not facolta:
                raise RuntimeError('Lo studente deve avere una facoltà')

        if self._is_professore and insegnamenti:
            for i in insegnamenti:
                self.add_corso_insegnato(i)

        self._luogo_di_nascita = {'citta': citta, 'regione': regione, 'nazione': nazione}

    def nome(self) -> str:
        return self._nome

    def cognome(self) -> str:
        return self._cognome

    def codice_fiscale(self) -> str:
        return self._codice_fiscale

    def is_studente(self) -> bool:
        return self._is_studente

    def is_professore(self) -> bool:
        return self._is_professore

    def luogo_di_nascita(self) -> dict:
        return self._luogo_di_nascita

    def matricola(self) -> str:
        if self._is_studente:
            return self._matricola
        raise AttributeError("La persona non è uno studente")

    def data_iscrizione(self) -> datetime:
        if self._is_studente:
            return self._data_iscrizione
        raise AttributeError("La persona non è uno studente")

    def facolta(self) -> Facolta:
        if self._is_studente:
            if self._facolta:
                return self._facolta
            raise RuntimeError("Lo studente non ha una facoltà associata")
        raise AttributeError("La persona non è uno studente")

    def add_corso_superato(self, corso: 'Corso', voto: 'Voto') -> None:
        if corso in self._corsi_superati:
            raise ValueError("Corso già superato")
        self._corsi_superati[corso] = voto

    def remove_corso_superato(self, corso: 'Corso') -> None:
        if corso not in self._corsi_superati:
            raise KeyError("Corso non presente tra i superati")
        del self._corsi_superati[corso]

    def corsi_superati(self) -> dict['Corso', 'Voto']:
        if self._is_studente:
            return self._corsi_superati
        raise AttributeError("La persona non è uno studente")

    def add_corso_insegnato(self, insegnamento: 'Insegnamento') -> None:
        self._insegnamenti.append(insegnamento)

    def remove_corso_insegnato(self, insegnamento: 'Insegnamento') -> None:
        self._insegnamenti.remove(insegnamento)

    def insegnamenti(self) -> list['Insegnamento']:
        if self._is_professore:
            return self._insegnamenti
        raise AttributeError("La persona non è un professore")

