export const anagrafica=[{
    id:"1",
    nome:"Diego",
    cognome:"Laghetti"
  },{
    id:"2",
    nome:"dido",
    cognome:"lago"
  },{
    id:"3",
    nome:"playdido",
    cognome:"didoplay"
  }];